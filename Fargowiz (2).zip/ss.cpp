#include<stdio.h>

int main(){
	
	int a=10;
	printf("%d %d %d %d",--a,++a,a++,a--);
}
